(() => {
  // extension/src/events.generated.js
  var events_generated_default = [
    {
      "id": "token2049-singapore-2026",
      "name": "TOKEN2049 Singapore 2026",
      "adapter": "webflow-finsweet",
      "agendaUrl": "https://token2049.com/singapore/agenda",
      "match": [
        "https://token2049.com/singapore/agenda*",
        "https://www.token2049.com/singapore/agenda*"
      ],
      "pagination": {
        "param": "630073d5_page",
        "maxPages": 20
      },
      "timezone": "Asia/Singapore",
      "venue": "Marina Bay Sands, Singapore",
      "titlePrefix": "[TOKEN2049] ",
      "stageAliases": {}
    }
  ];

  // src/adapters/webflow-finsweet/index.js
  var BOX = ".agenda-v2_card_box:not(.w-condition-invisible)";
  var webflow_finsweet_default = {
    name: "webflow-finsweet",
    item: ".agenda-v2_item",
    // Day-header cards ("Day 1, Wednesday...") are list items too; skip them.
    skip: ".agenda-v2_card_box.is-day-item:not(.w-condition-invisible)",
    fields: {
      day: '[fs-list-field="day"]',
      type: `${BOX} .agenda-v2_card_event-type`,
      range: `${BOX} .agenda-v2_card_meta-item:first-child`,
      duration: `${BOX} .agenda-v2_card_meta-item.is-time`,
      stage: `${BOX} [fs-list-field="stage"]`,
      title: `${BOX} .agenda-v2_card_title`
    },
    groups: {
      speakers: {
        item: `${BOX} .agenda-v2_card_speakers_item`,
        fields: {
          firstname: '[fs-list-field="firstname"]',
          lastname: '[fs-list-field="lastname"]',
          job: '[fs-list-field="job"]',
          company: '[fs-list-field="company"]',
          tag: ".agenda-v2_speakers_tag"
        }
      }
    },
    /** URLs to fetch for an event: Webflow paginates CMS lists with ?<listId>_page=N. */
    pageUrl(event2, n) {
      const u = new URL(event2.agendaUrl);
      if (event2.pagination?.param) u.searchParams.set(event2.pagination.param, String(n));
      return u.toString();
    },
    /** Is there another page after this HTML? (string check works in every runtime) */
    hasNextPage(html) {
      return /class="[^"]*w-pagination-next/.test(html);
    }
  };

  // src/adapters/index.js
  var ADAPTERS = { [webflow_finsweet_default.name]: webflow_finsweet_default };
  function getAdapter(event2) {
    const base = ADAPTERS[event2.adapter];
    if (!base) throw new Error(`Unknown adapter "${event2.adapter}" for event ${event2.id}`);
    const o = event2.adapterOverrides || {};
    return {
      ...base,
      ...o,
      fields: { ...base.fields, ...o.fields || {} },
      groups: { ...base.groups, ...o.groups || {} }
    };
  }

  // src/engines/text.js
  function joinTextNodes(nodes) {
    return nodes.map((t) => t.replace(/\s+/g, " ").trim()).filter(Boolean).join(" ").replace(/\s+/g, " ").trim();
  }

  // src/engines/dom.js
  function textOf(el) {
    if (!el) return "";
    const nodes = [];
    const walk = (n) => {
      let run = null;
      for (const c of n.childNodes) {
        if (c.nodeType === 3) {
          run = (run ?? "") + c.nodeValue;
          continue;
        }
        if (run !== null) {
          nodes.push(run);
          run = null;
        }
        if (c.nodeType === 1) walk(c);
      }
      if (run !== null) nodes.push(run);
    };
    walk(el);
    return joinTextNodes(nodes);
  }
  function parseItem(el, adapter) {
    if (adapter.skip && el.querySelector(adapter.skip)) return null;
    const rec = {};
    for (const [k, sel] of Object.entries(adapter.fields)) rec[k] = textOf(el.querySelector(sel));
    for (const [g, spec] of Object.entries(adapter.groups || {})) {
      rec[g] = [...el.querySelectorAll(spec.item)].map((ge) => {
        const sub = {};
        for (const [k, sel] of Object.entries(spec.fields)) sub[k] = textOf(ge.querySelector(sel));
        return sub;
      });
    }
    return rec;
  }
  function parseDom(root, adapter) {
    return [...root.querySelectorAll(adapter.item)].map((el) => parseItem(el, adapter)).filter(Boolean);
  }

  // src/core/time.js
  var MONTHS = [
    "january",
    "february",
    "march",
    "april",
    "may",
    "june",
    "july",
    "august",
    "september",
    "october",
    "november",
    "december"
  ];
  var pad = (n) => String(n).padStart(2, "0");
  function parseDay(text) {
    const m = /([A-Za-z]+)\s+(\d{1,2}),?\s+(\d{4})/.exec(text || "");
    if (!m) return null;
    const month = MONTHS.indexOf(m[1].toLowerCase()) + 1;
    if (!month) return null;
    return `${m[3]}-${pad(month)}-${pad(Number(m[2]))}`;
  }
  function parseClock(text) {
    const m = /(\d{1,2}):(\d{2})\s*([ap])\.?m\.?/i.exec(text || "");
    if (!m) return null;
    let h = Number(m[1]) % 12;
    if (m[3].toLowerCase() === "p") h += 12;
    return `${pad(h)}:${m[2]}`;
  }
  function parseRange(text) {
    const clocks = (text || "").match(/\d{1,2}:\d{2}\s*[ap]\.?m\.?/gi) || [];
    return { start: parseClock(clocks[0]), end: parseClock(clocks[1]) };
  }
  function parseDuration(text) {
    const h = /(\d+)\s*h/i.exec(text || "");
    const m = /(\d+)\s*min/i.exec(text || "");
    if (!h && !m) return null;
    return (h ? Number(h[1]) * 60 : 0) + (m ? Number(m[1]) : 0);
  }
  function addMinutes(local, minutes) {
    const [d, t] = local.split("T");
    const [y, mo, da] = d.split("-").map(Number);
    const [h, mi] = t.split(":").map(Number);
    const x = new Date(Date.UTC(y, mo - 1, da, h, mi + minutes));
    return `${x.getUTCFullYear()}-${pad(x.getUTCMonth() + 1)}-${pad(x.getUTCDate())}T${pad(x.getUTCHours())}:${pad(x.getUTCMinutes())}`;
  }
  function diffMinutes(a, b) {
    const toMs = (s) => {
      const [d, t] = s.split("T");
      const [y, mo, da] = d.split("-").map(Number);
      const [h, mi] = t.split(":").map(Number);
      return Date.UTC(y, mo - 1, da, h, mi);
    };
    return Math.round((toMs(b) - toMs(a)) / 6e4);
  }
  function zoneOffset(utcMs, timeZone) {
    const parts = Object.fromEntries(
      new Intl.DateTimeFormat("en-US", {
        timeZone,
        hourCycle: "h23",
        year: "numeric",
        month: "2-digit",
        day: "2-digit",
        hour: "2-digit",
        minute: "2-digit",
        second: "2-digit"
      }).formatToParts(new Date(utcMs)).map((p) => [p.type, p.value])
    );
    const asUtc = Date.UTC(+parts.year, +parts.month - 1, +parts.day, +parts.hour, +parts.minute, +parts.second);
    return Math.round((asUtc - utcMs) / 6e4);
  }
  function zonedToUtc(local, timeZone) {
    const [d, t] = local.split("T");
    const [y, mo, da] = d.split("-").map(Number);
    const [h, mi] = t.split(":").map(Number);
    const guess = Date.UTC(y, mo - 1, da, h, mi);
    let off = zoneOffset(guess, timeZone);
    let utc = guess - off * 6e4;
    const off2 = zoneOffset(utc, timeZone);
    if (off2 !== off) utc = guess - off2 * 6e4;
    return new Date(utc);
  }
  function toUtcStamp(date) {
    return date.toISOString().replace(/[-:]/g, "").replace(/\.\d{3}/, "");
  }

  // src/core/normalize.js
  var clean = (s) => s == null ? "" : String(s).replace(/\s+/g, " ").trim();
  function stableId(key) {
    const h = (seed) => {
      let x = seed >>> 0;
      for (let i = 0; i < key.length; i++) {
        x ^= key.charCodeAt(i);
        x = Math.imul(x, 16777619) >>> 0;
      }
      return x.toString(16).padStart(8, "0");
    };
    return h(2166136261) + h(16777619);
  }
  function normaliseStage(raw, aliases = {}) {
    const s = clean(raw);
    if (!s) return null;
    const hit = Object.entries(aliases).find(([k]) => k.toLowerCase() === s.toLowerCase());
    return hit ? hit[1] : s;
  }
  function speaker(raw) {
    const firstName = clean(raw.firstname);
    const lastName = clean(raw.lastname);
    const tag = clean(raw.tag).toLowerCase();
    return {
      name: clean(`${firstName} ${lastName}`),
      firstName,
      lastName,
      job: clean(raw.job),
      company: clean(raw.company),
      role: tag === "moderator" ? "moderator" : "speaker"
    };
  }
  function normalise(raws, event2) {
    const problems = [];
    const sessions = [];
    const seen = /* @__PURE__ */ new Map();
    raws.forEach((r, i) => {
      const day = parseDay(r.day);
      const range = parseRange(r.range);
      const start = range.start || parseClock(r.time);
      const title = clean(r.title);
      if (!day || !start || !title) {
        problems.push(`item ${i}: missing ${[!day && "day", !start && "start", !title && "title"].filter(Boolean).join(", ")}`);
        return;
      }
      const startLocal = `${day}T${start}`;
      let endLocal = null;
      const duration = parseDuration(r.duration);
      if (range.end) {
        endLocal = `${day}T${range.end}`;
        if (diffMinutes(startLocal, endLocal) <= 0) endLocal = addMinutes(endLocal, 24 * 60);
      } else if (duration) {
        endLocal = addMinutes(startLocal, duration);
      } else {
        endLocal = addMinutes(startLocal, event2.defaultDurationMin || 30);
        problems.push(`item ${i} (${title}): no end time, defaulted`);
      }
      const stage = normaliseStage(r.stage, event2.stageAliases);
      const baseId = stableId(`${event2.id}|${startLocal}|${stage || ""}|${title.toLowerCase()}`);
      const prefix = event2.titlePrefix || "";
      const displayTitle = prefix && !title.startsWith(prefix) ? `${prefix}${title}` : title;
      const n = (seen.get(baseId) || 0) + 1;
      seen.set(baseId, n);
      sessions.push({
        id: n === 1 ? baseId : `${baseId}-${n}`,
        event: event2.id,
        day,
        start: startLocal,
        end: endLocal,
        timezone: event2.timezone,
        durationMin: diffMinutes(startLocal, endLocal),
        stage,
        type: clean(r.type) || null,
        title: displayTitle,
        speakers: (r.speakers || []).map(speaker).filter((s) => s.name),
        venue: event2.venue || null,
        sourceUrl: event2.agendaUrl
      });
    });
    sessions.sort((a, b) => a.start.localeCompare(b.start) || (a.stage || "").localeCompare(b.stage || "") || a.title.localeCompare(b.title));
    return { sessions, problems };
  }

  // src/core/calendar.js
  function describe(session) {
    const lines = [];
    if (session.type) lines.push(session.type);
    if (session.stage) lines.push(`Stage: ${session.stage}`);
    const people = session.speakers.filter((s) => s.role === "speaker");
    const mods = session.speakers.filter((s) => s.role === "moderator");
    const fmt = (s) => [s.name, [s.job, s.company].filter(Boolean).join(", ")].filter(Boolean).join(" - ");
    if (people.length) lines.push("", "Speakers:", ...people.map((s) => `\u2022 ${fmt(s)}`));
    if (mods.length) lines.push("", "Moderator:", ...mods.map((s) => `\u2022 ${fmt(s)}`));
    if (session.sourceUrl) lines.push("", session.sourceUrl);
    return lines.join("\n");
  }
  function location2(session) {
    return [session.stage, session.venue].filter(Boolean).join(", ");
  }
  function utcRange(session) {
    return {
      start: zonedToUtc(session.start, session.timezone),
      end: zonedToUtc(session.end, session.timezone)
    };
  }
  function googleCalendarUrl(session) {
    const { start, end } = utcRange(session);
    const p = new URLSearchParams({
      action: "TEMPLATE",
      text: session.title,
      dates: `${toUtcStamp(start)}/${toUtcStamp(end)}`,
      details: describe(session),
      location: location2(session),
      ctz: session.timezone
    });
    return `https://calendar.google.com/calendar/render?${p.toString()}`;
  }
  var esc = (s) => String(s).replace(/\\/g, "\\\\").replace(/;/g, "\\;").replace(/,/g, "\\,").replace(/\r?\n/g, "\\n");
  function fold(line) {
    const enc = new TextEncoder();
    if (enc.encode(line).length <= 75) return line;
    const out = [];
    let cur = "";
    let bytes = 0;
    for (const ch of line) {
      const b = enc.encode(ch).length;
      const limit = out.length === 0 ? 75 : 74;
      if (bytes + b > limit) {
        out.push(cur);
        cur = "";
        bytes = 0;
      }
      cur += ch;
      bytes += b;
    }
    out.push(cur);
    return out.join("\r\n ");
  }
  function vevent(session, { domain, stamp }) {
    const { start, end } = utcRange(session);
    return [
      "BEGIN:VEVENT",
      `UID:${session.id}@${domain}`,
      `DTSTAMP:${stamp}`,
      `DTSTART:${toUtcStamp(start)}`,
      `DTEND:${toUtcStamp(end)}`,
      `SUMMARY:${esc(session.title)}`,
      `DESCRIPTION:${esc(describe(session))}`,
      `LOCATION:${esc(location2(session))}`,
      session.sourceUrl ? `URL:${session.sourceUrl}` : null,
      session.type ? `CATEGORIES:${esc(session.type)}` : null,
      "END:VEVENT"
    ].filter(Boolean);
  }
  function toIcs(sessions, opts = {}) {
    const domain = opts.domain || "token2049-agenda";
    const stamp = toUtcStamp(opts.now || /* @__PURE__ */ new Date());
    const lines = [
      "BEGIN:VCALENDAR",
      "VERSION:2.0",
      "PRODID:-//DeveloperAlly//token2049-agenda//EN",
      "CALSCALE:GREGORIAN",
      "METHOD:PUBLISH",
      opts.name ? `X-WR-CALNAME:${esc(opts.name)}` : null,
      "X-PUBLISHED-TTL:PT1H",
      ...sessions.flatMap((s) => vevent(s, { domain, stamp })),
      "END:VCALENDAR"
    ].filter(Boolean);
    return lines.map(fold).join("\r\n") + "\r\n";
  }

  // extension/src/content.js
  var PREFIX = "t2049x";
  var globToRegex = (g) => new RegExp(`^${g.replace(/[.+?^${}()|[\]\\]/g, "\\$&").replace(/\*/g, ".*")}$`);
  var event = events_generated_default.find((e) => (e.match || []).some((m) => globToRegex(m).test(location.href)));
  function download(filename, text) {
    const url = URL.createObjectURL(new Blob([text], { type: "text/calendar;charset=utf-8" }));
    const a = Object.assign(document.createElement("a"), { href: url, download: filename });
    document.body.appendChild(a);
    a.click();
    a.remove();
    setTimeout(() => URL.revokeObjectURL(url), 1e3);
  }
  var slug = (s) => s.toLowerCase().replace(/[^a-z0-9]+/g, "-").replace(/^-|-$/g, "").slice(0, 60) || "session";
  function button(label, title, onClick) {
    const b = document.createElement("button");
    b.type = "button";
    b.className = `${PREFIX}-btn`;
    b.textContent = label;
    b.title = title;
    b.addEventListener("click", (e) => {
      e.preventDefault();
      e.stopPropagation();
      onClick();
    });
    return b;
  }
  function injectStyles() {
    if (document.getElementById(`${PREFIX}-style`)) return;
    const s = document.createElement("style");
    s.id = `${PREFIX}-style`;
    s.textContent = `
    .${PREFIX}-bar{display:flex;gap:8px;flex-wrap:wrap;margin:10px 0 4px}
    .${PREFIX}-btn{font:600 12px/1 system-ui,-apple-system,Segoe UI,sans-serif;letter-spacing:.02em;
      padding:7px 10px;border-radius:6px;border:1px solid currentColor;background:transparent;color:inherit;cursor:pointer;opacity:.85}
    .${PREFIX}-btn:hover{opacity:1}
    .${PREFIX}-btn.${PREFIX}-primary{background:#1a73e8;border-color:#1a73e8;color:#fff}
    .${PREFIX}-all{margin:0 0 16px}`;
    document.head.appendChild(s);
  }
  async function fetchAll(adapter) {
    const raws = [];
    for (let n = 1; n <= (event.pagination?.maxPages || 20); n++) {
      const html = await (await fetch(adapter.pageUrl(event, n), { credentials: "omit" })).text();
      raws.push(...parseDom(new DOMParser().parseFromString(html, "text/html"), adapter));
      if (!event.pagination?.param || !adapter.hasNextPage(html)) break;
    }
    return normalise(raws, event).sessions;
  }
  function main() {
    if (!event) return;
    const adapter = getAdapter(event);
    const process = () => {
      for (const el of document.querySelectorAll(adapter.item)) {
        if (el.dataset[`${PREFIX}Done`]) continue;
        el.dataset[`${PREFIX}Done`] = "1";
        const raw = parseItem(el, adapter);
        if (!raw) continue;
        const { sessions: [s] } = normalise([raw], event);
        if (!s) continue;
        const mount = el.querySelector(adapter.mount || adapter.fields.title);
        if (!mount) continue;
        const bar = document.createElement("div");
        bar.className = `${PREFIX}-bar`;
        const gcal = button("Add to Google Calendar", "Opens Google Calendar with this session pre-filled", () => window.open(googleCalendarUrl(s), "_blank", "noopener"));
        gcal.classList.add(`${PREFIX}-primary`);
        bar.append(gcal, button(
          ".ics",
          "Download this session for Apple / Outlook calendars",
          () => download(`${slug(s.title)}.ics`, toIcs([s], { name: event.name, domain: `${event.id}.agenda` }))
        ));
        mount.insertAdjacentElement("afterend", bar);
      }
      const first = document.querySelector(adapter.item);
      if (first && !document.querySelector(`.${PREFIX}-all`)) {
        const all = document.createElement("div");
        all.className = `${PREFIX}-bar ${PREFIX}-all`;
        const allBtn = button("Download all sessions (.ics)", "Every session on every page and stage, not just the ones shown", async () => {
          allBtn.disabled = true;
          allBtn.textContent = "Fetching agenda...";
          try {
            const list = await fetchAll(adapter);
            download(`${event.id}.ics`, toIcs(list, { name: event.name, domain: `${event.id}.agenda` }));
            allBtn.textContent = `Downloaded ${list.length} sessions (.ics)`;
          } catch (err) {
            console.error(err);
            allBtn.textContent = "Download failed - try again";
          } finally {
            allBtn.disabled = false;
          }
        });
        all.append(allBtn);
        first.parentElement.insertAdjacentElement("beforebegin", all);
      }
    };
    injectStyles();
    process();
    let t = null;
    new MutationObserver(() => {
      clearTimeout(t);
      t = setTimeout(process, 150);
    }).observe(document.body, { childList: true, subtree: true });
  }
  main();
})();
